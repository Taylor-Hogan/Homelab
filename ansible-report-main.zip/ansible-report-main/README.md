# ansible-report
Building simple reports via CSVs and HTML with AAP and Ansible.

This is also a role for calling to generate CSVs and fire the email.
