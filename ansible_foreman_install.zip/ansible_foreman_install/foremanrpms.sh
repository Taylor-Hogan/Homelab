sudo wget https://yum.theforeman.org/releases/3.10/el9/x86_64/foreman-release.rpm
sudo dnf install -y foreman-release.rpm
sudo wget https://yum.theforeman.org/katello/4.12/katello/el9/x86_64/katello-repos-latest.rpm
sudo dnf install -y katello-repos-latest.rpm
sudo wget https://yum.puppet.com/puppet7-release-el-9.noarch.rpm
sudo dnf install -y puppet7-release-el-9.noarch.rpm
~                                                       